// Simulate login
document.getElementById('loginForm')?.addEventListener('submit', function (e) {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    if (username === 'user' && password === 'pass') {
        // Redirect to dashboard on successful login
        window.location.href = 'dashboard.html';
    } else {
        // Show error message
        document.getElementById('loginError').textContent = 'Invalid login details';
    }
});

// Handle logout
document.getElementById('logoutBtn')?.addEventListener('click', function () {
    window.location.href = 'loginpage.html';
});

// Load expenses from localStorage
function loadExpenses() {
    const expenseTable = document.getElementById('expenseTable').getElementsByTagName('tbody')[0];
    const expenses = JSON.parse(localStorage.getItem('expenses')) || [];

    expenseTable.innerHTML = ''; // Clear existing rows

    expenses.forEach((expense, index) => {
        const newRow = expenseTable.insertRow();
        const cell1 = newRow.insertCell(0);
        const cell2 = newRow.insertCell(1);
        const cell3 = newRow.insertCell(2);
        const cell4 = newRow.insertCell(3);
        const cell5 = newRow.insertCell(4);

        cell1.textContent = new Date(expense.date).toDateString();
        cell2.textContent = new Date(expense.date).toLocaleTimeString();

        cell3.textContent = expense.name;
        cell4.textContent = `₹${parseFloat(expense.amount).toFixed(2)}`;
        const deleteButton = document.createElement('button1');
        deleteButton.textContent = 'Delete';
        deleteButton.onclick = function () {
            deleteExpense(index);
        };
        cell5.appendChild(deleteButton);
    });
}

// Handle adding new expenses
document.getElementById('expenseForm')?.addEventListener('submit', function (e) {
    e.preventDefault();

    const expenseName = document.getElementById('expenseName').value;
    const expenseAmount = document.getElementById('expenseAmount').value;

    // Validate inputs
    if (expenseName.trim() === '' || isNaN(expenseAmount) || expenseAmount <= 0) {
        alert('Please enter valid expense details.');
        return;
    }

    // Save expense to localStorage
    const expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    expenses.push({ name: expenseName, amount: expenseAmount, date: new Date().toISOString() });
    localStorage.setItem('expenses', JSON.stringify(expenses));

    // Add expense to table
    loadExpenses(); // Reload expenses to reflect the new entry

    // Clear form fields
    document.getElementById('expenseName').value = '';
    document.getElementById('expenseAmount').value = '';
});

// Delete an expense
function deleteExpense(index) {
    const expenses = JSON.parse(localStorage.getItem('expenses')) || [];
    expenses.splice(index, 1); // Remove the expense at the specified index
    localStorage.setItem('expenses', JSON.stringify(expenses));
    loadExpenses(); // Reload expenses to reflect the changes
}

// Load expenses when the dashboard loads
window.onload = loadExpenses;
